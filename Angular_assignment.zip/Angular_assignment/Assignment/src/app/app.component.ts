import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment';
  amount=1000;
  isvalid:boolean=true;
  istrue:boolean=true;
  deposit(){
    this.amount=this.amount+100;
  }
  changevalue(valid){
    this.isvalid=valid;
  }
  changevalue1(valid1){
    this.istrue=valid1;
  }
}

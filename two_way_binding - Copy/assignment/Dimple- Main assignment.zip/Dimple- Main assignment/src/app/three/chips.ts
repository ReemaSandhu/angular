export interface Chips{
    id: number;
    code: string;
    url : string;
    name : string;
    unit : number;
    cost : number;
    rsp: any;
    margin: number;
    quantity: number;
    category: string
  }
  
import { MathFunPipe } from './math-fun.pipe';

describe('MathFunPipe', () => {
  it('create an instance', () => {
    const pipe = new MathFunPipe();
    expect(pipe).toBeTruthy();
  });
});

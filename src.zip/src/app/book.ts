export class Book {
    BookId: number | any;
    BookName: string  | any;
    AuthorName: string | any;
    PublicationYear: number | any;
    BookDescription: string | any;
    Price:number | any;
    Comments:string | any;
}